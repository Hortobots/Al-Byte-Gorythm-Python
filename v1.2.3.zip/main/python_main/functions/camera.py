import cv2
import time

class Camera:
    def __init__(self, camera_index=0):  # padrão 2
        self.camera_index = camera_index
        self.cap = cv2.VideoCapture(self.camera_index, cv2.CAP_DSHOW)  # se estiver no Windows

        if not self.cap.isOpened():
            raise RuntimeError(f"Erro: Não foi possível abrir a câmera no índice {self.camera_index}.")

        time.sleep(2)  # Espera a câmera inicializar

        self.setup_window()

    def setup_window(self):
        cv2.namedWindow("Image", cv2.WND_PROP_FULLSCREEN)
        cv2.setWindowProperty("Image", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)

    def get_frame(self):
        # Tenta ler até 10 vezes para garantir que a câmera "acordou"
        for attempt in range(10):
            success, img = self.cap.read()
            if success:
                return cv2.flip(img, 1)
            else:
                print(f"[Camera] Tentativa {attempt + 1}: falha ao capturar o frame.")
                time.sleep(0.3)

        raise RuntimeError("Não foi possível capturar o frame da câmera após várias tentativas.")

    def release(self):
        self.cap.release()
        cv2.destroyAllWindows()
