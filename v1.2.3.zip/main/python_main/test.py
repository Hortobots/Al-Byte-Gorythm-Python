import cv2
import numpy as np
import threading 
import time
import config
from functions.eye_position import EyePosition  # substitua 'olhos' pelo nome real do seu arquivo

# Inicializações
window_width, window_height = 800, 480
eye_position = EyePosition(window_width, window_height)

# Threads para animação e piscar
def blink_loop(eye_position):
    while True:
        time.sleep(5)
        eye_position.blink()

def animate_loop(eye_position):
    while True:
        time.sleep(0.05)
        eye_position.update_position()

threading.Thread(target=animate_loop, args=(eye_position,), daemon=True).start()
threading.Thread(target=blink_loop, args=(eye_position,), daemon=True).start()

# Expressões disponíveis
expressoes = {
    0: "NENHUMA",
    1: "NEUTRO",
    2: "ENTEDIADO",
    3: "RAIVA",
    4: "OLHO DIREITO FECHADO",
    5: "OLHO ESQUERDO FECHADO",
    6: "RINDO",
    7: "PONTO E VÍRGULA",
    8: "ERRO",
    9: "TRISTE"
}

expressao = 1  # valor inicial
config.ROBOT_EXPRESSION_INDEX = expressao

def main():
    global expressao
    total_expressoes = len(expressoes)

    while True:
        img = np.full((window_height, window_width, 3), config.BACKGROUND_COLOR, dtype=np.uint8)
        eye_position.draw(img)

        texto = f"Expressao: {expressao} - {expressoes.get(expressao, 'DESCONHECIDA')}"
        cv2.putText(img, texto, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)

        cv2.imshow("Olhos do Robo", img)
        key = cv2.waitKey(50) & 0xFF

        if key == 27:  # ESC
            break
        elif key == ord('d'):
            expressao = (expressao + 1) % total_expressoes
            config.ROBOT_EXPRESSION_INDEX = expressao
        elif key == ord('a'):
            expressao = (expressao - 1) % total_expressoes
            config.ROBOT_EXPRESSION_INDEX = expressao

    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()