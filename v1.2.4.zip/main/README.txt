Hello, This is the code responsible for the operation of the Al B. Gorithm Robot from the Sesi Hortobots team at Sesi CE Unit 437 - Hortolândia, Brazil.

The code is currently in version 1.2.3.